.. include:: ../README.rst

.. include:: ../CREDITS.txt

.. include:: ../CHANGES.txt

