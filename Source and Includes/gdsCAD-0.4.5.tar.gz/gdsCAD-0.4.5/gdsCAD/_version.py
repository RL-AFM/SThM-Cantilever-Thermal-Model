
# This version number is untracked and may not be up to date. 
# It is updated during source builds.

__version__ = '0.4.5'
