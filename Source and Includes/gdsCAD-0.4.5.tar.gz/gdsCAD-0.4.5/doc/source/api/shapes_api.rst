********************
:mod:`gdsCAD.shapes`
********************

.. automodule:: gdsCAD.shapes

Inheritance Diagram
===================

.. inheritance-diagram:: gdsCAD.shapes
    :parts: 2

Class Summary
=============
.. currentmodule:: gdsCAD.shapes

.. autosummary::
    Box
    Rectangle
    Disk
    Circle
    RegPolygon
    RegPolyline
    Label


Class Definitions
=================
.. automodule:: gdsCAD.shapes
   :members:
   :undoc-members:
   :show-inheritance:
