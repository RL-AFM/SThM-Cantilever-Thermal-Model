**************
The gdsCAD API
**************

gdsCAD is divided into several modules:

.. currentmodule:: gdsCAD

.. autosummary::
    core
    shapes
    utils
    templates

Contents
========
.. toctree::
    
    core_api.rst
    shapes_api.rst
    utils_api.rst
    templates_api.rst
    

