************************
:mod:`gdsCAD.templates`
************************

.. automodule:: gdsCAD.templates


Class Summary
================
.. currentmodule:: gdsCAD.templates

Wafer Classes
------------------------
.. autosummary::
    Wafer_GridStyle
    Wafer_Style1
    Wafer_Style2
    Block

Alignment Marks
---------------
.. autosummary::
    AlignmentMarks
    Verniers

Module Definitions
==================
.. automodule:: gdsCAD.templates
   :members:
   :undoc-members:
   :show-inheritance:
